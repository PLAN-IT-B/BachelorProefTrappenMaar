Before contributing to the KiCad symbol libraries, it is recommended to read the [contribution guidelines](http://kicad.org/libraries/contribute).

Contributions to the KiCad libraries must meet the [KiCad Library Conventions (KLC)](http://kicad.org/libraries/klc/)
